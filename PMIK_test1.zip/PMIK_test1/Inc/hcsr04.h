/*
 * hcsr04.h
 *
 *  Created on: Jan 8, 2020
 *      Author: Iga
 */

#ifndef HCSR04_H_
#define HCSR04_H_

int counter1, counter2 ;
int start ;

void distance() ;
void send_init() ;
void send_string(char* s);


#endif /* HCSR04_H_ */
