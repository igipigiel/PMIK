/*
 * RGB_LED.c
 *
 *  Created on: 1 gru 2019
 *      Author: Marcin
 */
#include "RGB_LED.h"

static bool isActive = true;
static uint8_t buffer[24 * LED_COUNT];
static uint16_t buffIdx;
static SPI_HandleTypeDef *hspi;
static float H;
static float S;
static float V;
static float R;
static float G;
static float B;
static int goalR;
static int goalG;
static int goalB;
static float dR;
static float dG;
static float dB;
static int mode = IDLE;
static float strobFreq;

uint8_t getR() {
	return (uint8_t) R;
}
uint8_t getG() {
	return (uint8_t) G;
}

uint8_t getB() {
	return (uint8_t) B;
}

void initializeLEDs(SPI_HandleTypeDef *hspiInit, float HInit, float SInit,
		float VInit) {
	hspi = hspiInit;
	H = HInit;
	S = SInit;
	V = VInit;
	makeBufferFromHSV(H, S, V);
	sendBuffer();
}

void startRainbow() {
	V = 0.7;
	mode = RAINBOW;
}
void startColorPicker(int destR, int destG, int destB, int time) {
	goalR = destR;
	goalG = destG;
	goalB = destB;
	dR = (goalR - R) / (time * FREQUENCY);
	dG = (goalG - G) / (time * FREQUENCY);
	dB = (goalB - B) / (time * FREQUENCY);
	mode = COLOR_PICKER;
}
void startStrobotron(float frequency) {
	V = 0.7;
	strobFreq = frequency;
	mode = STROBOTRON;
}

void startIdle() {
	mode = IDLE;
}

void toggleLEDsActive() {
	isActive = !isActive;
}

void setIlluminance(float illuminance) {
	V = illuminance;
}

void setColorBit(uint32_t color) {
	--buffIdx;
	if (color % 2 == 0)
		buffer[buffIdx] = ZERO;
	else
		buffer[buffIdx] = ONE;
}

void HSVtoRGB(float H, float S, float V) {
	float R_p, G_p, B_p;
	float C = V * S;
	float mod = H / 60.0;
	while (mod > 0)
		mod -= 2;
	mod += 1;
	if (mod < 0)
		mod *= -1;
	float X = C * (1 - mod);
	float m = V - C;
	if (H >= 0 && H < 60) {
		R_p = C;
		G_p = X;
		B_p = 0;
	} else if (H >= 60 && H < 120) {
		R_p = X;
		G_p = C;
		B_p = 0;
	} else if (H >= 120 && H < 180) {
		R_p = 0;
		G_p = C;
		B_p = X;
	} else if (H >= 180 && H < 240) {
		R_p = 0;
		G_p = X;
		B_p = C;
	} else if (H >= 240 && H < 300) {
		R_p = X;
		G_p = 0;
		B_p = C;
	} else if (H >= 300 && H < 360) {
		R_p = C;
		G_p = 0;
		B_p = X;
	} else
		return;

	R = (uint8_t) ((R_p + m) * 255);
	G = (uint8_t) ((G_p + m) * 255);
	B = (uint8_t) ((B_p + m) * 255);
}

void makeBufferFromHSV(float H, float S, float V) {
	HSVtoRGB(H, S, V);
	makeBufferFromRGB((uint8_t) R, (uint8_t) G, (uint8_t) B);
}

void makeBufferFromRGB(uint8_t red, uint8_t green, uint8_t blue) {
	uint16_t j = 0;
	uint16_t t = 0;
	buffIdx = 24 * LED_COUNT;
	uint32_t GRB_bits = (green << 16) + (red << 8) + blue;
	for (j = 0; j < LED_COUNT; ++j) {
		for (t = 0; t < 24; ++t) {
			setColorBit(GRB_bits >> t);
		}
	}
	t++;
}

void sendBuffer() {
	HAL_SPI_Transmit(hspi, buffer, 24 * LED_COUNT, 1000);
}

void makeRainbowStep() {
	H += 2;
	if (H > 360)
		H = 0;
	makeBufferFromHSV(H, S, V);
	sendBuffer();
}

void makeColorPickerStep() {
	if ((goalR - R >= 0 && goalR - R < dR)
			|| (goalR - R <= 0 && goalR - R > dR)) {
		R = goalR;
		G = goalG;
		B = goalB;
		mode = IDLE;
	} else {
		R += dR;
		G += dG;
		B += dB;
	}
	makeBufferFromRGB((uint8_t) R, (uint8_t) G, (uint8_t) B);
	sendBuffer();

}

int strobCounter = 0;

void makeStrobotronStep() {
	if(++strobCounter > FREQUENCY / strobFreq) {
		strobCounter = 0;
		H = rand() % 360;
		makeBufferFromHSV(H, S, V);
		sendBuffer();
	}
}

bool toggleLamp() {
	isActive = !isActive;
	return isActive;
}

int makeLampStep() {
	if (!isActive)
		return;
	switch (mode) {
	case RAINBOW:
		makeRainbowStep();
		break;

	case COLOR_PICKER:
		makeColorPickerStep();
		break;

	case STROBOTRON:
		makeStrobotronStep();
		break;

	}
	return mode;
}
