/*
 * hcsr04.c
 *
 *  Created on: Jan 8, 2020
 *      Author: Iga
 */
#include "main.h"
GPIO_PinState last ;
extern int mode ;
extern int start ;
extern int counter1, counter2 ;
void send_init() {

	if (start == 1){
		start = 2 ;
		HAL_GPIO_WritePin(Trigg_GPIO_Port, Trigg_Pin, GPIO_PIN_SET);
	}
	else {
		HAL_GPIO_WritePin(Trigg_GPIO_Port, Trigg_Pin, GPIO_PIN_RESET);
	}
}

void distance(){

	GPIO_PinState current ;
	if ((current = HAL_GPIO_ReadPin(Trigg_GPIO_Port, Echo_Pin)) == GPIO_PIN_SET){
		counter1++ ;
	}else if (last == GPIO_PIN_SET){
		counter2 = counter1 ;
		//size = sprintf(str,"%d\n",counter2) ;
		counter1 = 0 ;
		if (counter2 > 14 && counter2 < 600) {

		} else mode = IDLE ;
		start = 0;
		//HAL_UART_Transmit_IT(&huart2, str, size);
	}
	last = current;
}
