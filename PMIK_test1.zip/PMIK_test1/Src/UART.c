/*
 * UART.c
 *
 *  Created on: 23 gru 2019
 *      Author: Marcin
 */
#include "UART.h"

static char dataToSend[100];
static UART_HandleTypeDef *huart;

static enum receive_flag {
	MODE, RGB_CODE, TIME, FREQ, NONE
} flag;

void initUart(UART_HandleTypeDef *initHuart) {
	huart = initHuart;
}

void sendMessage(char *dataToSend, uint16_t size) {
	HAL_UART_Transmit_IT(huart, (unsigned char*) dataToSend, size); // Rozpoczecie nadawania danych z wykorzystaniem przerwan
}
char Received[20];
char Data[100];

void receiveMessage(int length) {
	HAL_UART_Receive_IT(huart, (unsigned char*) Received, length); // Ponowne włączenie nasłuchiwania
}

void sendEndColorPickerMessage() {
	uint16_t size;
	size = sprintf(Data, "Ustawiono wybrany kolor.\n\rPodaj kolejny kolor RGB w formacie HEX XXXXXX.\n\r");
	sendMessage(Data, size);
	flag = RGB_CODE;
	receiveMessage(6);
}

void receiveMode() {
	uint16_t size, receiveSize;
	switch (atoi(Received)) {
	case 0: // Jezeli odebrany zostanie znak 0
		size = sprintf(Data, "Wybrano tryb color picker.\n\rPodaj wybrany kolor RGB w formacie HEX XXXXXX.\n\r");
		flag = RGB_CODE;
		receiveSize = 6;
		break;
	case 1: // Jezeli odebrany zostanie znak 1
		size = sprintf(Data, "Wybrano tryb strobotron. Podaj czestotliwosc pracy trybu w Hz w formacie XXXXXX.\n\r");
		flag = FREQ;
		receiveSize = CHAR_COUNT;
		break;
	case 2: // Jezeli odebrany zostanie znak 2
		size = sprintf(Data, "Wybrano tryb rainbow.\n\r");
		startRainbow();
		flag = NONE;
		break;
	default: // Jezeli odebrano nieobslugiwany znak
		flag = MODE;
		receiveSize = 1;
		break;
	}
	sendMessage(Data, size); // Rozpoczecie nadawania danych z wykorzystaniem przerwan
	if (flag != NONE)
		receiveMessage(receiveSize);
}

uint8_t R, G, B;

uint32_t receiveRGBCode() {
	uint16_t size;
	uint32_t code = 0;
	code = (uint32_t) strtol(Received, NULL, 16);
	R = (code >> 4 * 4) % 0x100;
	G = (code >> 4 * 2) % 0x100;
	B = code % 0x100;
	size = sprintf(Data, "Wybrano kolor R=%d G=%d B=%d\n\rPodaj czas zmiany koloru w s w formacie XXXXXX.\n\r", R, G, B);
	sendMessage(Data, size); // Rozpoczecie nadawania danych z wykorzystaniem przerwan
	flag = TIME;
	receiveMessage(CHAR_COUNT);
	return code;
}

float receiveNumber() {
	float number = 0;
	number = atoi(&Received);
	return number;
}

void receiveTime() {
	uint16_t size;
	float time = receiveNumber();
	size = sprintf(Data, "Wybrano czas %.4fs.", time);
	sendMessage(Data, size); // Rozpoczecie nadawania danych z wykorzystaniem przerwan
	startColorPicker(R, G, B, time);
	flag = NONE;
}

void receiveFrequency() {
	uint16_t size;
	float freq = receiveNumber();
	size = sprintf(Data, "Wybrano czestotliwosc %.4fHz.", freq);
	sendMessage(Data, size); // Rozpoczecie nadawania danych z wykorzystaniem przerwan
	startStrobotron(freq);
	flag = NONE;
}

void startProgram() {
	int size;
	size =
			sprintf(dataToSend,
					"SMART LAMPA\n\rWybierz tryb pracy:\n\r0 - color picker\n\r1 - strobotron\n\r2 - rainbow\n\r"); // Stworzenie wiadomosci do wyslania oraz przypisanie ilosci wysylanych znakow do zmiennej size.
	sendMessage(dataToSend, size); // Rozpoczecie nadawania danych z wykorzystaniem przerwan
	flag = MODE;
	receiveMessage(1);
}

void sendColorMessage() {
	int size;
	size = sprintf(Data, "Zatrzymano tryb na kolorze R=%d G=%d B=%d.\n\r", getR(), getG(), getB());
	sendMessage(Data, size); // Rozpoczecie nadawania danych z wykorzystaniem przerwan
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
	uint16_t size = 0; // Rozmiar wysylanej wiadomosci
	switch (flag) {
	case MODE:
		receiveMode();
		break;
	case RGB_CODE:
		receiveRGBCode();
		break;
	case TIME:
		receiveTime();
		break;
	case FREQ:
		receiveFrequency();
		break;
	default:
		break;
	}
	// Odebrany znak zostaje przekonwertowany na liczbe calkowita i sprawdzony
	// instrukcja warunkowa
}
